﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.IO.Ports;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using CRC_Calculation;
using FTD2XX_NET;
using Hardcodet.Wpf.TaskbarNotification.Interop;
using System.IO;
//using ServerMonitor;


namespace ServerMonitor
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 
    //public delegate void ViewDataFromSerialPort(string Obg);




    public partial class MainWindow : Window
    {
        //FTDI MyFT2232 = new FTDI();

        SerialPort PortServerMonitor = new SerialPort(); //Create an instance of class SerialPort
        //inUartData inUartData_read = new inUartData();
        private delegate void ViewDataFromSerialPort(string String);
        private delegate void ToggleColor(bool a);
        //CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("en-US");
        private static bool FirstWarningTemperature = false;
        private static bool FirstWarningHumidity = false;
        private static bool FirstWarningPressure = false;
        private static bool FirstWarningDust = false;
        private static bool FirstWarningVibration = false;
        private static bool flagFirstOpenCase = false;
        //private static long countWorkTime = 0;
        private static bool FlagOpenCase = false;

        public MainWindow()
        {
            InitializeComponent();            
            ServerId();
            TimerSet();
            this.ScanPort_Click(this, null);
            ConnectPort_Click(this, null);
            //Properties.Settings.Default.Reset();
        }

        //***********************************************************************************************************
        //Add Id to title
        private void ServerId()
        {
            String path = Directory.GetCurrentDirectory() + "\\serverId.txt";

            try
            {
                using (StreamReader fstream = new StreamReader(path, System.Text.Encoding.Default))
                {
                    this.Title += " " + fstream.ReadLine();
                }
            }
            catch (FileNotFoundException e)
            {
                //File.Create(path);
                using (StreamWriter fstream = new StreamWriter(path, false, System.Text.Encoding.Default))
                {
                    fstream.WriteLine("");
                }
                MessageBox.Show("File \"serverId\" is created\r\n" + "Please enter your Id", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //***********************************************************************************************************
        //Timer set
        public static void TimerSet()
        {
            Timer TimerWriteLog = new Timer(300000);
            TimerWriteLog.Elapsed += TimerWriteLog_Elapsed;
            TimerWriteLog.AutoReset = true;
            TimerWriteLog.Enabled = true;
            
            //Properties.Settings.Default.CheckBoxEnable = false;
            //Properties.Settings.Default.Save();
        }

        private static void TimerWriteLog_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (Properties.Settings.Default.CheckBoxEnable)
            {
                if (!Properties.Settings.Default.FlagLogWrite) Properties.Settings.Default.FlagLogWrite = true;
                //else Properties.Settings.Default.FlagLogWrite = false;
                Properties.Settings.Default.Save();
                //throw new NotImplementedException();
            }

            WriteWorkDataInFile();
        }


        //***********************************************************************************************************
        //
        private void ClosedMainWindow(object sender, EventArgs e)
        {
            try
                {
                    PortServerMonitor.Close();
                }
            catch (System.IO.IOException)
                {             
                    MessageBox.Show("Device unavailable. Check the connection.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            catch (System.UnauthorizedAccessException)
                {
                    MessageBox.Show("Unable to close port. Check the connection.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            WriteWorkDataInFile();


        }

        //***********************************************************************************************************
        //
        private static void WriteWorkDataInFile()
        {
            //Properties.Settings.Default.CounterWorkTime += countWorkTime;
            //Properties.Settings.Default.Save();
            //countWorkTime = 0;

            String path = Directory.GetCurrentDirectory() + "\\worktime.txt";

            using (StreamWriter fstream = new StreamWriter(path, false, System.Text.Encoding.Default))
            {
                long timeMS = Properties.Settings.Default.CounterWorkTime;
                int cntDay = (int)((((timeMS / 1000) / 60) / 60) / 24);
                timeMS = timeMS - (cntDay * 24 * 60 * 60 * 1000);
                int cntHour = (int)(((timeMS / 1000) / 60) / 60);
                timeMS = timeMS - (cntHour * 60 * 60 * 1000);
                int cntMinute = (int)((timeMS / 1000) / 60);

                fstream.WriteLine("Software total work counter: " + cntDay + " Day " + cntHour + " Hour " + cntMinute + " Minute ");
                //fstream.WriteLine("Hardware total work counter: " + Properties.Settings.Default.WorkDayCount + " Day " +
                //                  Properties.Settings.Default.WorkHourCount + " Hour " +
                //                  Properties.Settings.Default.WorkMinuteCount + " Minute ");
                fstream.WriteLine("Hardware current work counter: " + Properties.Settings.Default.WorkDayCurrentCount + " Day " +
                                  Properties.Settings.Default.WorkHourCurrentCount + " Hour " +
                                  Properties.Settings.Default.WorkMinuteCurrentCount + " Minute ");
                fstream.WriteLine("Open case counter: " + Properties.Settings.Default.CounterOpenCase);
            }
        }


        //***********************************************************************************************************
        //
        private void ScanPort_Click(object sender, RoutedEventArgs e)
        {
            string[] GetPortList = SerialPort.GetPortNames();
            bool PortInList = false;
            //int tmp = 0;

            PortList.Items.Clear();                                        //cleare textbox
            if (!PortServerMonitor.IsOpen)
                {
                    RXTX_Indication.Fill = Brushes.Yellow;
                }
            SavePort.IsEnabled = true;
            foreach (string PortListName in GetPortList)                   //find available ports
                {
                    PortList.Items.Add(PortListName);
                    if (PortListName == Properties.Settings.Default.PortName)               //com port variable in Settings.settings
                        {
                            PortInList = true;

                            //PortList.Items.Remove(Properties.Settings.Default.PortName);
                            PortList.Items.RemoveAt(PortList.Items.IndexOf(PortListName));
                            PortList.Items.Insert(0, Properties.Settings.Default.PortName);
                            PortList.SelectedIndex = 0;
                            
                        }
                }

            if (!PortList.HasItems)
                {
                    PortList.Items.Add("Ports Not Found");
                    SavePort.IsEnabled = false;
                    if (!PortServerMonitor.IsOpen)
                        {
                            RXTX_Indication.Fill = Brushes.Red;
                        }
                }

            if (!PortInList)
            {
                PortList.SelectedIndex = 0;
            }

        }

        //***********************************************************************************************************
        //
        private void SavePort_Click(object sender, RoutedEventArgs e)
            {
                Properties.Settings.Default.PortName = PortList.Text;
                Properties.Settings.Default.Save();

                ClosePort();
                ConnectPort_Click(this, null);
            }

        //***********************************************************************************************************
        //
        private void ConnectPort_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //PortServerMonitor.PortName = PortList.Text;

                PortServerMonitor.PortName = Properties.Settings.Default.PortName;
                PortServerMonitor.BaudRate = 115200;
                PortServerMonitor.DataBits = 8;
                PortServerMonitor.Parity = Parity.None;
                PortServerMonitor.StopBits = StopBits.One;
                PortServerMonitor.ReadTimeout = 10;
                PortServerMonitor.WriteTimeout = 10;
                PortServerMonitor.ReceivedBytesThreshold = 14;
                PortServerMonitor.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler_1);
                PortServerMonitor.Open();                                       //open current serial port
                //ScanPort.IsEnabled = false;
                RXTX_Indication.Fill = Brushes.Green;
            }
            catch (ArgumentException)
            {
                RXTX_Indication.Fill = Brushes.Red;
                MessageBox.Show("Port's Not Available.\r\n" + "Please Perform a New Search for Ports.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (InvalidOperationException)
            {
                PortServerMonitor.Close();
                RXTX_Indication.Fill = Brushes.Red;
                MessageBox.Show("Port is Closed!\r\n" + "Please Try Again.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.IO.IOException)
            {
                //PortList.Items.Remove(PortList.Text);
                RXTX_Indication.Fill = Brushes.Red;
                MessageBox.Show("Current Port Unavailable. Check the connection.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.UnauthorizedAccessException)
            {
                //PortList.Items.Remove(PortList.Text);
                RXTX_Indication.Fill = Brushes.Red;
                MessageBox.Show("Current Port is Busy.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //***********************************************************************************************************
        //
        public struct inUartData                                                                           
        {
            public int Id;
            public float Temperature;
            public float Humidity;
            public float Pressure;
            public int Vibration;
            public int Dust;
            public int DayCurrent;
            public int HourCurrent;
            public int MinuteCurrent;
            public int DayTotal;
            public int HourTotal;
            public int MinuteTotal;
            public int ContactState;
            public int Xaxis;
            public int Yaxis;
            public int Zaxis;
            public int CRC8;

            public inUartData(byte[] inData)
            {
                Id = inData[0];
                Temperature = (sbyte)inData[1] + (sbyte)inData[2] * 0.01f;
                Humidity = inData[3] + inData[4] * 0.01f;
                Pressure = inData[5] * 256 + inData[6] + (inData[7] * 256 + inData[8]) * 0.001f;
                Vibration = inData[10];
                Dust = inData[11] * 256 + inData[12];
                DayCurrent = inData[13] * 256 + inData[14];
                HourCurrent = inData[15];
                MinuteCurrent = inData[16];
                DayTotal = inData[17] * 256 + inData[18];
                HourTotal = inData[19];
                MinuteTotal = inData[20];
                ContactState = inData[21];
                Xaxis = inData[22];
                Yaxis = inData[23];
                Zaxis = inData[24];
                CRC8 = inData[25];
            }
        };

        //***********************************************************************************************************
        //
        private void DataReceivedHandler_1(object sender, SerialDataReceivedEventArgs e)
        {   
            SerialPort PortServerMonitorInData = (SerialPort)sender;
            //inUartData inUartData_read = new inUartData(BufferIn);

            byte[] BufferIn = new byte[26]; //for new version 22 bytes (it's old version)

            if (PortServerMonitorInData.BytesToRead >= BufferIn.Length)
            {

                PortServerMonitorInData.Read(BufferIn, 0, BufferIn.Length);
                //inUartData_read.inUartDataInit(BufferIn);
                inUartData inUartData_read = new inUartData(BufferIn);

                byte crc = CRCCount.ComputeChecksum(BufferIn);
                // here check should equal 0 to show that the checksum is accurate
                if (crc == 0)
                {
                    TimeCounter(inUartData_read.DayCurrent, inUartData_read.HourCurrent, inUartData_read.MinuteCurrent); //count work time every 600 mS and Read time devises data
                    //PeekCaseOpen(inUartData_read.ContactState);
                    //PeekCaseOpenDownUp(inUartData_read.ContactState);
                    PeekCaseOpenUpDown(inUartData_read.ContactState);
                    LogWrite(inUartData_read.Temperature, inUartData_read.Humidity, inUartData_read.Pressure, inUartData_read.Dust, inUartData_read.Vibration);
                    WarningReadOneTime(inUartData_read.Temperature, inUartData_read.Humidity, inUartData_read.Pressure, inUartData_read.Dust, inUartData_read.Vibration);
                    //ReturnWarningNormalFlagState();

                    //Temperature.Dispatcher.BeginInvoke(new ViewDataFromSerialPort(ReadTemperature), String.Format(CultureInfo.GetCultureInfo("en-US"), "{0,7:#00.00}", _Temperature));
                    Temperature.Dispatcher.BeginInvoke(new ViewDataFromSerialPort(ReadTemperature), inUartData_read.Temperature.ToString("#00.00", CultureInfo.GetCultureInfo("en-US")));
                    Humidity.Dispatcher.BeginInvoke(new ViewDataFromSerialPort(ReadHumidity), inUartData_read.Humidity.ToString("00.00", CultureInfo.GetCultureInfo("en-US")));
                    Pressure.Dispatcher.BeginInvoke(new ViewDataFromSerialPort(ReadPressure), inUartData_read.Pressure.ToString("000.00", CultureInfo.GetCultureInfo("en-US")));
                    Dust.Dispatcher.BeginInvoke(new ViewDataFromSerialPort(ReadDust), inUartData_read.Dust.ToString("000"));
                    Vibration.Dispatcher.BeginInvoke(new ViewDataFromSerialPort(ReadVib), inUartData_read.Vibration.ToString("00"));

                    //RXTX_Indication.Dispatcher.BeginInvoke(new ToggleColor(ToggleIndicationRed), false);
                }
                else { MessageBox.Show("Error Checksum", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
            else { RXTX_Indication.Dispatcher.BeginInvoke(new ToggleColor(ToggleIndicationRed), false); }
        }

        //***********************************************************************************************************
        //
        public void ClosePort()
        {
            try
            {
                PortServerMonitor.Close();
            }
            catch (System.IO.IOException)
            {
                MessageBox.Show("Device unavailable. Check the connection.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (System.UnauthorizedAccessException)
            {
                MessageBox.Show("Unable to close port. Check the connection.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //***********************************************************************************************************
        //Counter work time 
        private static void TimeCounter(int Day, int Hour, int Minute)
        {
            //countWorkTime += 600;
            Properties.Settings.Default.CounterWorkTime += 600;
            Properties.Settings.Default.WorkDayCurrentCount = Day;
            Properties.Settings.Default.WorkHourCurrentCount = Hour;
            Properties.Settings.Default.WorkMinuteCurrentCount = Minute;          
            Properties.Settings.Default.Save();
        }

        //***********************************************************************************************************
        //Case is open?
        private static void PeekCaseOpen(int caseFlag)
        {
            String path = Directory.GetCurrentDirectory() + "\\warning.txt";

            if (caseFlag == 0)
            {
                FlagOpenCase = true;
            }

            if(FlagOpenCase)
            {
                if(caseFlag == 1)
                {
                    FlagOpenCase = false;
                    Properties.Settings.Default.CounterOpenCase += 1;
                    Properties.Settings.Default.Save();

                    using (StreamWriter fstream = new StreamWriter(path, true, System.Text.Encoding.Default))
                    {
                        fstream.WriteLine("Warning_Intrusion " + DateTime.Now + " --> " + "counter is - " + Properties.Settings.Default.CounterOpenCase);
                    }
                }
            }
        }

        //***********************************************************************************************************
        //Case is open?
        private static void PeekCaseOpenDownUp(int caseFlag)
        {
            String path = Directory.GetCurrentDirectory() + "\\warning.txt";

            if (caseFlag == 0 && !flagFirstOpenCase)
            {
                flagFirstOpenCase = true;
                Properties.Settings.Default.CounterOpenCase += 1;
                Properties.Settings.Default.Save();

                using (StreamWriter fstream = new StreamWriter(path, true, System.Text.Encoding.Default))
                {
                    fstream.WriteLine("Warning_Intrusion " + DateTime.Now + " --> " + "counter is " + Properties.Settings.Default.CounterOpenCase);
                }
            } else
            {
                if (caseFlag == 1 && flagFirstOpenCase)
                {
                    flagFirstOpenCase = false;
                }
            }
        }

        //***********************************************************************************************************
        //Case is open?
        private static void PeekCaseOpenUpDown(int caseFlag)
        {
            String path = Directory.GetCurrentDirectory() + "\\warning.txt";

            if (caseFlag == 1 && !flagFirstOpenCase)
            {
                flagFirstOpenCase = true;
                Properties.Settings.Default.CounterOpenCase += 1;
                Properties.Settings.Default.Save();

                using (StreamWriter fstream = new StreamWriter(path, true, System.Text.Encoding.Default))
                {
                    fstream.WriteLine("Warning_Intrusion " + DateTime.Now + " --> " + "counter is - " + Properties.Settings.Default.CounterOpenCase);
                }
            }
            else
            {
                if (caseFlag == 0 && flagFirstOpenCase)
                {
                    flagFirstOpenCase = false;
                }
            }
        }

        //***********************************************************************************************************
        //Every X minutes write log
        private static void LogWrite(float _Temperature, float _Humidity, float _Pressure, int _Dust, int _Vibration)
        {
            String path = Directory.GetCurrentDirectory() + "\\warning.txt";

            if (Properties.Settings.Default.FlagLogWrite)
            {
                using (StreamWriter fstream = new StreamWriter(path, true, System.Text.Encoding.Default))
                {
                    if (_Temperature > Properties.Settings.Default.WarningTemperature)
                    {
                        fstream.WriteLine(DateTime.Now + " --> " + "Temperature - " + _Temperature.ToString("#00.00", CultureInfo.GetCultureInfo("en-US")) + " " + "C");
                    }

                    if (_Humidity > Properties.Settings.Default.WarningHumidity)
                    {
                        fstream.WriteLine(DateTime.Now + " --> " + "Humidity - " + _Humidity.ToString("00.00", CultureInfo.GetCultureInfo("en-US")) + " " + "%");
                    }

                    if (_Pressure > Properties.Settings.Default.WarningPressure)
                    {
                        fstream.WriteLine(DateTime.Now + " --> " + "Pressure - " + _Pressure.ToString("000.00", CultureInfo.GetCultureInfo("en-US")) + " " + "mm");
                    }

                    if (_Dust > Properties.Settings.Default.WarningDust)
                    {
                        fstream.WriteLine(DateTime.Now + " --> " + "Dust - " + _Dust.ToString("000") + " " + "mkg");
                    }

                    if (_Vibration > Properties.Settings.Default.WarningVib)
                    {
                        fstream.WriteLine(DateTime.Now + " --> " + "Vibration - " + _Vibration.ToString("00"));
                    }
                }

                Properties.Settings.Default.FlagLogWrite = false;
                Properties.Settings.Default.Save();
            }
        }

        //***********************************************************************************************************
        //Just time read warning info
        private static void WarningReadOneTime(float _Temperature, float _Humidity, float _Pressure, int _Dust, int _Vibration)
        {
            String path = Directory.GetCurrentDirectory() + "\\warning.txt";
            // запись в файл
            if (Properties.Settings.Default.WarningActive)
            {
                using (StreamWriter fstream = new StreamWriter(path, true, System.Text.Encoding.Default))
                {
                    if (_Temperature > Properties.Settings.Default.WarningTemperature && !FirstWarningTemperature)
                    {
                        fstream.WriteLine("Warning_Temperature" + " " + DateTime.Now + " --> " + "Temperature - " + _Temperature.ToString("#00.00", CultureInfo.GetCultureInfo("en-US")) + " " + "C");
                        FirstWarningTemperature = true;
                    }
                    else
                    {
                        if (_Temperature < Properties.Settings.Default.WarningTemperature && FirstWarningTemperature)
                        {
                            fstream.WriteLine("Normal_Temperature" + " " + DateTime.Now + " --> " + "Temperature - " + _Temperature.ToString("#00.00", CultureInfo.GetCultureInfo("en-US")) + " " + "C");
                            FirstWarningTemperature = false;
                        }
                    }

                    if (_Humidity > Properties.Settings.Default.WarningHumidity && !FirstWarningHumidity)
                    {
                        fstream.WriteLine("Warning_Humidity" + " " + DateTime.Now + " --> " + "Humidity - " + _Humidity.ToString("00.00", CultureInfo.GetCultureInfo("en-US")) + " " + "%");
                        FirstWarningHumidity = true;
                    }
                    else
                    {
                        if (_Humidity < Properties.Settings.Default.WarningHumidity && FirstWarningHumidity)
                        {
                            fstream.WriteLine("Normal_Humidity" + " " + DateTime.Now + " --> " + "Humidity - " + _Humidity.ToString("00.00", CultureInfo.GetCultureInfo("en-US")) + " " + "%");
                            FirstWarningHumidity = false;
                        }
                    }

                    if (_Pressure > Properties.Settings.Default.WarningPressure && !FirstWarningPressure)
                    {
                        fstream.WriteLine("Warning_Pressure" + " " + DateTime.Now + " --> " + "Pressure - " + _Pressure.ToString("000.00", CultureInfo.GetCultureInfo("en-US")) + " " + "mm");
                        FirstWarningPressure = true;
                    }
                    else
                    {
                        if (_Pressure < Properties.Settings.Default.WarningPressure && FirstWarningPressure)
                        {
                            fstream.WriteLine("Normal_Pressure" + " " + DateTime.Now + " --> " + "Pressure - " + _Pressure.ToString("000.00", CultureInfo.GetCultureInfo("en-US")) + " " + "mm");
                            FirstWarningPressure = false;
                        }
                    }

                    if (_Dust > Properties.Settings.Default.WarningDust && !FirstWarningDust)
                    {
                        fstream.WriteLine("Warning_Dust" + " " + DateTime.Now + " --> " + "Dust - " + _Dust.ToString("000") + " " + "mkg");
                        FirstWarningDust = true;
                    }
                    else
                    {
                        if (_Dust < Properties.Settings.Default.WarningDust && FirstWarningDust)
                        {
                            fstream.WriteLine("Normal_Dust" + " " + DateTime.Now + " --> " + "Dust - " + _Dust.ToString("000") + " " + "mkg");
                            FirstWarningDust = false;
                        }
                    }

                    if (_Vibration > Properties.Settings.Default.WarningVib && !FirstWarningVibration)
                    {
                        fstream.WriteLine("Warning_Vibration" + " " + DateTime.Now + " --> " + "Vibration - " + _Vibration.ToString("00"));
                        FirstWarningVibration = true;
                    }
                    else
                    {
                        if (_Vibration < Properties.Settings.Default.WarningVib && FirstWarningVibration)
                        {
                            fstream.WriteLine("Normal_Vibration" + " " + DateTime.Now + " --> " + "Vibration - " + _Vibration.ToString("00"));
                            FirstWarningVibration = false;
                        }
                    }
                }
            }
        }

        //***********************************************************************************************************
        //
        public void ReadTemperature(string Temp)
            {
                Temperature.Content = Temp;
            }

        //***********************************************************************************************************
        //
        public void ReadHumidity(string Hum)
            {
                Humidity.Content = Hum;
            }

        //***********************************************************************************************************
        //
        public void ReadPressure(string Press)
            {
                Pressure.Content = Press;
            }

        //***********************************************************************************************************
        //
        public void ReadDust(string Dst)
            {
                this.Dust.Content = Dst;
            }

        //***********************************************************************************************************
        //
        public void ReadVib(string Vib)
            {
                Vibration.Content = Vib;
            }

        //***********************************************************************************************************
        //
        public void ToggleIndicationRed(bool a)
        {
            if (RXTX_Indication.Fill == Brushes.Green)
                {
                    RXTX_Indication.Fill = Brushes.Red;
                }
            else if (RXTX_Indication.Fill == Brushes.Red)
                {
                    RXTX_Indication.Fill = Brushes.Green;
                }
        }

        //***********************************************************************************************************
        //
        public void ToggleIndicationGreen(bool a)
        {
            RXTX_Indication.Fill = Brushes.Green;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ControlWindow controlWindow = new ControlWindow();
            controlWindow.Show();
        }
    }
    
    
}
