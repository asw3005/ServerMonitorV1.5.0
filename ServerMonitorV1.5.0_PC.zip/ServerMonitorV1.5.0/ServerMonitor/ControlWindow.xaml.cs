﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Globalization;
using System.Timers;


namespace ServerMonitor
{
    /// <summary>
    /// Interaction logic for ControlWindow.xaml
    /// </summary>
    public partial class ControlWindow : Window
    {
        public ControlWindow()
        {
            InitializeComponent();
            WarTemperature.Text = (Properties.Settings.Default.WarningTemperature).ToString();
            WarHumidity.Text = (Properties.Settings.Default.WarningHumidity).ToString();
            WarPressure.Text = (Properties.Settings.Default.WarningPressure).ToString();
            WarDust.Text = (Properties.Settings.Default.WarningDust).ToString();
            WarVib.Text = (Properties.Settings.Default.WarningVib).ToString();
            
            //TimerSet();
            //if (LogEnable.IsChecked == true)  Properties.Settings.Default.CheckBoxEnable = true;
            //else Properties.Settings.Default.CheckBoxEnable = false;
            //Properties.Settings.Default.Save();

            if (Properties.Settings.Default.CheckBoxEnable) LogEnable.IsChecked = true;
            else LogEnable.IsChecked = false;


            if (Properties.Settings.Default.WarningActive) ButtonWarningClick.Background = Brushes.Red;
            else ButtonWarningClick.Background = Brushes.LightGray;
        }

        private void ButtonClickSaveWarning(object sender, RoutedEventArgs e)
        {
            if (WarningCheckEnDis.IsChecked  == true)
            {
                try
                {
                    Properties.Settings.Default.WarningTemperature = float.Parse(WarTemperature.Text, CultureInfo.InvariantCulture.NumberFormat);
                    Properties.Settings.Default.WarningHumidity = float.Parse(WarHumidity.Text, CultureInfo.InvariantCulture.NumberFormat);
                    Properties.Settings.Default.WarningPressure = float.Parse(WarPressure.Text, CultureInfo.InvariantCulture.NumberFormat);
                    Properties.Settings.Default.WarningDust = int.Parse(WarDust.Text, CultureInfo.InvariantCulture.NumberFormat);
                    Properties.Settings.Default.WarningVib = int.Parse(WarVib.Text, CultureInfo.InvariantCulture.NumberFormat);
                    Properties.Settings.Default.WarningActive = true;
                }
                catch (System.FormatException)
                {
                    MessageBox.Show("Invalid argument.\r\n" + "Please insert the valid data.", "ServerMonitor", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                ButtonWarningClick.Background = Brushes.Red;
                Properties.Settings.Default.Save();

            } else
            {
                ButtonWarningClick.Background = Brushes.LightGray;
                Properties.Settings.Default.WarningActive = false;
                Properties.Settings.Default.Save();
            }
        }

        private void LogEnable_CheckBox(object sender, RoutedEventArgs e)
        {
            if (LogEnable.IsChecked == true) Properties.Settings.Default.CheckBoxEnable = true;
            else Properties.Settings.Default.CheckBoxEnable = false;
            Properties.Settings.Default.Save();
        }



        //***********************************************************************************************************
        //
        private void View(string viewString)
        {
            WorkTime.Text = viewString;
        }

        private void ResetCounter_click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.CounterOpenCase = 0;
            Properties.Settings.Default.Save();
        }
    }
}
