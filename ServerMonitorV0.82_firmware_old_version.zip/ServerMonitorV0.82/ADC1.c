/* Created: 24.06.2018
 * ADC1.h
 *
 *
 *
 */
 
#include "stm32f10x.h"
#include "ADC1.h" 

//*************************************************************************************************
//Настройка АЦП 
void ADC1InitForDustSensor(void)
{        		 
  NVIC_SetPriority (ADC1_2_IRQn, 4);		                      //назначить приоритет прерывания  
  NVIC_EnableIRQ (ADC1_2_IRQn);				                        //глобальное разрешение прерываения 
  
  GPIOA->CRL	&= ~GPIO_CRL_CNF0;                              //Сброс CNF в 00, аналоговый режим работы
  GPIOA->CRL  &= ~GPIO_CRL_MODE0;                             //Установка режима вход
  
  RCC->CFGR |= RCC_CFGR_ADCPRE_0;                             //Деление частоты на 4 (36МГц/4)
  RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;		                      //включить тактирование 
  
  ADC1->CR1 |= ADC_CR1_JEOCIE | ADC_CR1_JDISCEN;            //Однократное преобразование для injected каналов, включить прерывание при окончании преобразования
  ADC1->CR2 |= ADC_CR2_JEXTTRIG | ADC_CR2_JEXTSEL_2;          //Включить запуск преобразования от события TRGO от TIM3
  ADC1->CR2 |= ADC_CR2_ADON;
  //ADC1->JOFR1 |= 0x115;                                        //Смещение, вычитаемое из преобразованного значения, 12 бит
  //ADC1->JSQR |= ~ADC_JSQR_JL_0 | ~ADC_JSQR_JSQ1;              //Кол-во каналов на преобразование 1, номер канал 0 (ADC12_IN0)
  
  
//  __NOP();__NOP();__NOP();
//  __NOP();__NOP();__NOP();
//  ADC1->CR2 |= ADC_CR2_CAL;                                   //Калибровка при первом включении
}
