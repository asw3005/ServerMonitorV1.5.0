/* Created: 23.06.2018
 * TIM3.h
 *
 *
 *
 */	
 
 
#include "stm32f10x.h"
#include "TIM3.h" 

//*************************************************************************************************
//Настройка таймера для формирования измерительного сигнала датчика пыли
void TimInitForDustSensor(void)
{        		 
  NVIC_SetPriority (TIM3_IRQn, 3);		                      //назначить приоритет прерывания от таймера 2 
  NVIC_EnableIRQ (TIM3_IRQn);				                          //глобальное разрешение прерываения таймера 2
  
  GPIOA->CRL	&= ~GPIO_CRL_CNF6;                              //Сброс CNF в 00
  GPIOA->CRL	|= GPIO_CRL_CNF6_1;                             //Установка режима AF-PP
  GPIOA->CRL  |= GPIO_CRL_MODE6_0;                            //Установка режима outmax 10MHz 
  
  RCC->APB1ENR |=RCC_APB1ENR_TIM3EN;		                      //включить тактирование таймера 2
  Timer->PSC = 359; 				                                  //предделитель таймера (при 36МГц, делителе 360, после деления 100КГц - 10мкс	
  Timer->ARR = 1000;					  		                          //значение предзагрузки/перезагрузки	(10ms)	1000!
  Timer->CCR1 = 32;
  Timer->CCR4 = 28;
  Timer->CCMR1 |= TIM_CCMR1_OC1M | TIM_CCMR1_OC1PE;           //Режим PWM2, включить выход сигнала, PA6
  Timer->CCER |= TIM_CCER_CC1E;
  
  Timer->CCMR2 |= TIM_CCMR2_OC4M | TIM_CCMR2_OC4PE;           //Режим PWM2, включить выход сигнала
  Timer->CCER |= TIM_CCER_CC4E;
  
  Timer->CR1 |= TIM_CR1_URS | TIM_CR1_ARPE;			              //обновление с помощью бита UG не устанавливает флаг прерывания
  //Timer->CR1 |= TIM_CR2_MMS;
  Timer->EGR |= TIM_EGR_UG;				                            //генерация события обновления  
  Timer->DIER |= TIM_DIER_UIE;			                          //включить вызов прерывания от события от таймера
  
  //Timer->CR1 |= TIM_CR1_CEN;			                            //включение таймера	
  //TIM2->SR &= ~TIM_SR_UIF;                                  //
                                                              //TIM3_CCR4 - ивент для АЦП на 280мкс
}


