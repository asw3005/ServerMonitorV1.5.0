/* Created: 23.06.2018
 * TIM1.h
 *
 *
 *
 */	
 
 
#include "stm32f10x.h"
#include "TIM1.h" 

//*************************************************************************************************
//Настройка таймера для циклического опроса датчиков (частота 1с)
void Tim1InitForDustSensor(void)
{        		 
  //NVIC_SetPriority (TIM1_IRQn, 5);		                      //назначить приоритет прерывания от таймера 2 
  NVIC_EnableIRQ(TIM1_UP_IRQn);			                          //глобальное разрешение прерываения таймера 2
  
  GPIOA->CRH	&= ~GPIO_CRH_CNF9;                              //Сброс CNF в 00
  GPIOA->CRH	|= GPIO_CRH_CNF9_1;                             //Установка режима AF-PP
  GPIOA->CRH  |= GPIO_CRH_MODE9_0;                            //Установка режима outmax 10MHz 
  
  RCC->APB2ENR |=RCC_APB2ENR_TIM1EN;		                      //включить тактирование таймера 2
  Timer->PSC = 359; 				                                  //предделитель таймера (при 36МГц, делителе 360, после деления 100КГц - 10мкс	
  Timer->ARR = 1000;					  		                          //значение предзагрузки/перезагрузки	(10ms)	1000!
  Timer->CCR2 = 32;
  Timer->CCR3 = 28;
  Timer->CCMR1 |= TIM_CCMR1_OC2M | TIM_CCMR1_OC2PE;           //Режим PWM2, включить выход сигнала, PA9
  Timer->CCER |= TIM_CCER_CC2E;
  Timer->BDTR |= TIM_BDTR_MOE;
  Timer->CR1 |= TIM_CR1_URS | TIM_CR1_ARPE;			              //обновление с помощью бита UG не устанавливает флаг прерывания  | TIM_CR1_OPM
  Timer->EGR |= TIM_EGR_UG;				                            //генерация события обновления  
  Timer->DIER |= TIM_DIER_UIE;			                          //включить вызов прерывания от события от таймера
  
  Timer->CR1 |= TIM_CR1_CEN;			                            //включение таймера	
  //TIM2->SR &= ~TIM_SR_UIF;
}


