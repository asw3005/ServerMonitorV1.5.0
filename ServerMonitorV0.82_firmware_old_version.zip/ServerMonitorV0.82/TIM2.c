/* Created: 23.06.2018
 * TIM2.h
 *
 *
 *
 */	
 
 
#include "stm32f10x.h"
#include "TIM2.h" 

//*************************************************************************************************
//Настройка таймера 
void TimInitForVibSensor(void)
{        		 
  NVIC_SetPriority (TIM2_IRQn, 5);		                      //назначить приоритет прерывания от таймера 2 
  NVIC_EnableIRQ (TIM2_IRQn);				                          //глобальное разрешение прерываения таймера 2
  
  RCC->APB1ENR |=RCC_APB1ENR_TIM2EN;		                      //включить тактирование таймера 2
  Timer2->PSC = 719; 				                                  //предделитель таймера (при 36МГц, делителе 360, после деления 100КГц - 10мкс	
  //Timer2->ARR = 50000;					  		                          //значение предзагрузки/перезагрузки	(10ms)	1000!
  //Timer->CCR1 = 32;
  //Timer->CCR4 = 28;
  Timer2->SMCR |= TIM_SMCR_TS_1 | TIM_SMCR_TS_2 | TIM_SMCR_SMS_2 | TIM_SMCR_ETF;
  
  Timer2->CCMR1 |= TIM_CCMR1_CC2S_0;                           //Режим входа, TI2
  Timer2->CCER |= TIM_CCER_CC2E;                               //Включить 4й канал захвата


  Timer2->CR1 |= TIM_CR1_URS | TIM_CR1_ARPE;			              //обновление с помощью бита UG не устанавливает флаг прерывания
  Timer2->EGR |= TIM_EGR_UG;				                            //генерация события обновления  
  Timer2->DIER |= TIM_DIER_UIE | TIM_DIER_CC2IE;			          //включить вызов прерывания от события от таймера
  
  //Timer2->CR1 |= TIM_CR1_CEN;			                            //включение таймера	
  //TIM2->SR &= ~TIM_SR_UIF;                                  //
                                                              //TIM3_CCR4 - ивент для АЦП на 280мкс
}


