/* Created: 29.06.2018
 * DustSensor.h
 *
 *
 *
 */
 
#include "stm32f10x.h"
#include "ADC1.h" 
#include "TIM3.h"


uint32_t Dust, ADC_Dust;
uint8_t DustDataCounter;


//**********************************************************************************************************************************
//Измерить текущее содержание пыли в воздухе
void getDust(void)
{
  DustDataCounter = 0;                        //Подготовка для считывания показаний пыли
  //ADC_Dust = 0;
  GPIOA->CRL	&= ~GPIO_CRL_CNF6;              //Сброс CNF в 00
  GPIOA->CRL	|= GPIO_CRL_CNF6_1;             //Установка режима AF-PP
  GPIOA->CRL  |= GPIO_CRL_MODE6_0;            //Установка режима outmax 10MHz 
  Timer->CR1 |= TIM_CR1_CEN;			            //включение таймера
  while(DustDataCounter < 10){}               //Накопить 30 измерений
  Timer->CR1 &= ~TIM_CR1_CEN;			            //выключение таймера
  ADC1->SR &= ~ADC_SR_JEOC;                   //Сброс флага окончания преобразования
  GPIOA->CRL	&= ~GPIO_CRL_CNF6;              //Сброс CNF в 00
  GPIOA->CRL  |= GPIO_CRL_MODE6_0;            //Установка режима outmax 10MHz  
  GPIOA->BSRR = GPIO_BSRR_BS6;
  ADC_Dust = ADC_Dust/10;                     //Посчитать среднее оцифрованное значение
    
  if (ADC_Dust < 1400)
    {
      Dust = 0;
    }
  else     
    {  
      ADC_Dust = (ADC_Dust * 805)/1000;       //Перевести оцифрованное значение в напряжение
      ADC_Dust = ADC_Dust - 900;              //Вычесть начальное смещение датчика
      Dust = (10*ADC_Dust - 11);               //Перевести напряжение на выходе датчика в микрограммы
      Dust = Dust/53;
      
      if (Dust > 490)
          {
            Dust = 500;
          }
    }
  
}



