/* Created: 27.05.2018
 * BME280.c
 *  
 * 
 * 
 */	

#include "stm32f10x.h"
#include "BME280.h"
#include "BME280Variable.h"
#include "i2c1.h"

uint8_t QuantityByteI2C1Tx;
uint8_t QuantityByteI2C1Rx;
uint8_t CounterByteI2C1Tx;
uint8_t CounterByteI2C1Rx;
uint8_t FlagCalibDataRead;
uint8_t FlagConfigEn;
uint8_t FlagWriteData;
uint8_t FlagReadData;
uint8_t FlagTxEnable;
uint8_t FlagRxEnable;
uint8_t FlagRestartEn;
uint8_t FlagSwitch;
uint8_t RxBufferAddr;
uint8_t TxBufferI2C1[10];
uint8_t RxBufferI2C1[121];
uint8_t *PointerTxBuffer;
uint8_t *PointerRxBuffer;
uint8_t FlagTim2Cmp;

int32_t t_fine;

//**********************************************************************************************************************************
//Подготовка конфигурационных данных (работа внутри помещения)
void BME280PreparationConfig(void)                              
{
  uint8_t *pointer_0;
  
  BME280ConfigBit.osrs_h = OSRS_H_OVERSAMPLING_1;
  BME280ConfigBit.mode = NORMAL_MODE;
  BME280ConfigBit.osrs_p = OSRS_P_OVERSAMPLING_16;
  BME280ConfigBit.osrs_t = OSRS_T_OVERSAMPLING_2;
  BME280ConfigBit.spi3w_en = SPI3WIRE_DIS;
  BME280ConfigBit.t_sb = T_SB_500mS;
  BME280ConfigBit.filter = FILTER_COEFF16;
 
  TxBufferI2C1[AddressBME280] = ADDR_BME280_WRITE_MODE;
  TxBufferI2C1[AddressRegisterCtrlHum] = CTRL_HUM_ADDR;
  pointer_0 = (uint8_t *)& BME280ConfigBit;
  TxBufferI2C1[DataCtrlHum] = (*pointer_0);
  
  TxBufferI2C1[AddressRegisterCtrlMeas] = CTRL_MEAS_ADDR;
  pointer_0 = (uint8_t *)& BME280ConfigBit;
  pointer_0 = pointer_0 + 1;
  TxBufferI2C1[DataCtrlMeas] = (*pointer_0);
  
  TxBufferI2C1[AddressRegisterConfig] = CONFIG_ADDR;
  pointer_0 = (uint8_t *)& BME280ConfigBit;
  pointer_0 = pointer_0 + 2;
  TxBufferI2C1[DataConfig] = (*pointer_0);
}

//**********************************************************************************************************************************
//Запись конфигурационных данных 
void BME280WriteConfig(void)                              
{
  FlagTxEnable = 1;
  FlagWriteData = 1;
  FlagSwitch = 1;
  QuantityByteI2C1Tx = 6;
  TxBufferI2C1[AddressRegisterCtrlHum] = CTRL_HUM_ADDR;
  BME280WriteAddress(WRITE_MODE);
  //I2C1_Enable();
  //I2C1_Init();
  I2C1_Start();
  
}

//**********************************************************************************************************************************
//Получить калибровочные данные первый диапазон 
void getBME280CalibrationData0(void)                              
{
  FlagTxEnable = 1;
  FlagRxEnable = 1;
  FlagRestartEn = 1;
  FlagWriteData = 1;
  FlagReadData = 1;
  QuantityByteI2C1Tx = 1;
  QuantityByteI2C1Rx = 26;
  RxBufferAddr = dig_T1_LSB;
  TxBufferI2C1[1] = CALIB00_START_ADDR;
  BME280WriteAddress(WRITE_MODE);
  //I2C1_Enable();
  I2C1_Start();
}

//**********************************************************************************************************************************
//Получить калибровочные данные первый диапазон 
void getBME280CalibrationData1(void)                              
{
  FlagTxEnable = 1;
  FlagRxEnable = 1;
  FlagRestartEn = 1;
  FlagWriteData = 1;
  FlagReadData = 1;
  QuantityByteI2C1Tx = 1;
  QuantityByteI2C1Rx = 7;
  RxBufferAddr = dig_H2_LSB;
  TxBufferI2C1[1] = CALIB26_START_ADDR;
  BME280WriteAddress(WRITE_MODE);
  //I2C1_Enable();
  I2C1_Start();
}

//**********************************************************************************************************************************
//Получить данные о давлении, температуре и влажности 
void getBME280DataPressTempHum(void)                              
{
  FlagTxEnable = 1;
  FlagRxEnable = 1;
  FlagRestartEn = 1;
  FlagWriteData = 1;
  FlagReadData = 1;
  QuantityByteI2C1Tx = 1;
  QuantityByteI2C1Rx = 8;
  RxBufferAddr = press_msb;
  TxBufferI2C1[1] = PRESS_MSB_ADDR;
  BME280WriteAddress(WRITE_MODE);
  //I2C1_Enable();
  I2C1_Start();
}

//**********************************************************************************************************************************
//Преобразование давления 
// Returns pressure in Pa as unsigned 32 bit integer. Output value of “96386” equals 96386 Pa = 963.86 hPa
uint32_t BME280PressureConv(void)                              
{
  int32_t var1, var2, var3, var4;  
  int16_t dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;
  uint16_t dig_P1;
  uint32_t P, adc_P, P_min = 30000, P_max = 110000, var5;
  
  dig_P1 = RxBufferI2C1[dig_P1_MSB];
  dig_P1 = dig_P1<<8;
  dig_P1 |= RxBufferI2C1[dig_P1_LSB];
  
  dig_P2 = RxBufferI2C1[dig_P2_MSB];
  dig_P2 = dig_P2<<8;
  dig_P2 |= RxBufferI2C1[dig_P2_LSB];
  
  dig_P3 = RxBufferI2C1[dig_P3_MSB];
  dig_P3 = dig_P3<<8;
  dig_P3 |= RxBufferI2C1[dig_P3_LSB];
  
  dig_P4 = RxBufferI2C1[dig_P4_MSB];
  dig_P4 = dig_P4<<8;
  dig_P4 |= RxBufferI2C1[dig_P4_LSB];
  
  dig_P5 = RxBufferI2C1[dig_P5_MSB];
  dig_P5 = dig_P5<<8;
  dig_P5 |= RxBufferI2C1[dig_P5_LSB];
  
  dig_P6 = RxBufferI2C1[dig_P6_MSB];
  dig_P6 = dig_P6<<8;
  dig_P6 |= RxBufferI2C1[dig_P6_LSB];
  
  dig_P7 = RxBufferI2C1[dig_P7_MSB];
  dig_P7 = dig_P7<<8;
  dig_P7 |= RxBufferI2C1[dig_P7_LSB];
  
  dig_P8 = RxBufferI2C1[dig_P8_MSB];
  dig_P8 = dig_P8<<8;
  dig_P8 |= RxBufferI2C1[dig_P8_LSB];
  
  dig_P9 = RxBufferI2C1[dig_P9_MSB];
  dig_P9 = dig_P9<<8;
  dig_P9 |= RxBufferI2C1[dig_P9_LSB];

  adc_P = RxBufferI2C1[press_msb];
  adc_P = adc_P<<8;
  adc_P |= RxBufferI2C1[press_lsb];
  adc_P = adc_P<<8;
  adc_P |= RxBufferI2C1[press_xlsb];
  adc_P = adc_P>>4;

	var1 = (((int32_t)t_fine) / 2) - (int32_t)64000;
	var2 = (((var1 / 4) * (var1 / 4)) / 2048) * ((int32_t)dig_P6);
	var2 = var2 + ((var1 * ((int32_t)dig_P5)) * 2);
	var2 = (var2 / 4) + (((int32_t)dig_P4) * 65536);
	var3 = (dig_P3 * (((var1 / 4) * (var1 / 4)) / 8192)) / 8;
	var4 = (((int32_t)dig_P2) * var1) / 2;
	var1 = (var3 + var4) / 262144;
	var1 = (((32768 + var1)) * ((int32_t)dig_P1)) / 32768;
	 /* avoid exception caused by division by zero */
	if (var1) 
    {
      var5 = (uint32_t)((uint32_t)1048576) - adc_P;
      P = ((uint32_t)(var5 - (uint32_t)(var2 / 4096))) * 3125;
      if (P < 0x80000000)        
        {
          P = (P << 1) / ((uint32_t)var1);
        }
      else
        {
          P = (P / (uint32_t)var1) * 2;
        }
      var1 = (((int32_t)dig_P9) * ((int32_t)(((P / 8) * (P / 8)) / 8192))) / 4096;
      var2 = (((int32_t)(P / 4)) * ((int32_t)dig_P8)) / 8192;
      P = (uint32_t)((int32_t)P + ((var1 + var2 + dig_P7) / 16));

      if (P < P_min){P = P_min;}       
      else 
        {
         if (P > P_max)
            {P = P_max;}
        }
    } 
  else 
    {
      P = P_min;
    }

	return P;
}

//**********************************************************************************************************************************
//Преобразование температуры 
//Returns temperature in DegC, resolution is 0.01 DegC. Output value of “5123” equals 51.23 DegC.
//t_fine carries fine temperature as global value
int32_t BME280TemperatureConv(void)                              
{ 
  int32_t var1, var2, T, T_min = -4000, T_max = 8500;
  uint32_t adc_T;
  uint16_t dig_T1;
  int16_t dig_T2, dig_T3;
  
  dig_T1 = RxBufferI2C1[dig_T1_MSB];
  dig_T1 = dig_T1<<8;
  dig_T1 |= RxBufferI2C1[dig_T1_LSB];
  
  dig_T2 = RxBufferI2C1[dig_T2_MSB];
  dig_T2 = dig_T2<<8;
  dig_T2 |= RxBufferI2C1[dig_T2_LSB];
  
  dig_T3 = RxBufferI2C1[dig_T3_MSB];
  dig_T3 = dig_T3<<8;
  dig_T3 |= RxBufferI2C1[dig_T3_LSB];
  
  adc_T = RxBufferI2C1[temp_msb];
  adc_T = adc_T<<8;
  adc_T |= RxBufferI2C1[temp_lsb];
  adc_T = adc_T<<8;
  adc_T |= RxBufferI2C1[temp_xlsb];
  adc_T = adc_T>>4;

  var1 = (int32_t)((adc_T / 8) - ((int32_t)dig_T1 * 2));
	var1 = (var1 * ((int32_t)dig_T2)) / 2048;
	var2 = (int32_t)((adc_T / 16) - ((int32_t)dig_T1));
	var2 = (((var2 * var2) / 4096) * ((int32_t)dig_T3)) / 16384;
	t_fine = var1 + var2;
	T = (t_fine * 5 + 128) / 256;

	if (T < T_min)
    {T = T_min;}
	else if (T > T_max)
    {T = T_max;}
  
  return T;
}

//**********************************************************************************************************************************
//Преобразование влажности 
//Returns humidity in %RH as unsigned 32 bit integer in Q22.10 format (22 integer and 10 fractional bits).
//Output value of “47445” represents 47445/1024 = 46.333 %RH
uint32_t BME280HumidityConv(void)                              
{
  int32_t  var1, var2, var3, var4, var5;
  int16_t  dig_H2, dig_H4, dig_H5, dig_H6;
  uint16_t dig_H1, dig_H3;
  uint32_t adc_H, Hum, Hum_max = 102400; 
  
  dig_H1 = RxBufferI2C1[dig_H1_LSB];
  
  dig_H2 = RxBufferI2C1[dig_H2_MSB];            //Смещение +1 т.к. при считывании остался баг считывания пустого значения FF, всё смещено на 1, при дальнейших считываниях смещений нет - ИСПРАВЛЕНО
  dig_H2 = dig_H2<<8;
  dig_H2 |= RxBufferI2C1[dig_H2_LSB];
  
  dig_H3 = RxBufferI2C1[dig_H3_LSB];
  
  dig_H4 = RxBufferI2C1[dig_H4_MSB];
  dig_H4 = dig_H4<<4;
  dig_H5 = RxBufferI2C1[dig_H4H5_LSB];
  dig_H5 &= 0x0F;
  dig_H4 |= dig_H5;
  
  dig_H5 = RxBufferI2C1[dig_H5_MSB];
  dig_H5 = dig_H5<<4;
  dig_H6 = RxBufferI2C1[dig_H4H5_LSB];
  dig_H6 &= 0xF0;
  dig_H6 = dig_H6>>4;
  dig_H5 |= dig_H6;
  
  dig_H6 = RxBufferI2C1[dig_H6_LSB];
  
  adc_H = RxBufferI2C1[hum_msb];
  adc_H = adc_H<<8;
  adc_H |= RxBufferI2C1[hum_lsb]; 

  var1 = t_fine - ((int32_t)76800);
	var2 = (int32_t)(adc_H * 16384);
	var3 = (int32_t)(((int32_t)dig_H4) * 1048576);
	var4 = ((int32_t)dig_H5) * var1;
	var5 = (((var2 - var3) - var4) + (int32_t)16384) / 32768;
	var2 = (var1 * ((int32_t)dig_H6)) / 1024;
	var3 = (var1 * ((int32_t)dig_H3)) / 2048;
	var4 = ((var2 * (var3 + (int32_t)32768)) / 1024) + (int32_t)2097152;
	var2 = ((var4 * ((int32_t)dig_H2)) + 8192) / 16384;
	var3 = var5 * var2;
	var4 = ((var3 / 32768) * (var3 / 32768)) / 128;
	var5 = var3 - ((var4 * ((int32_t)dig_H1)) / 16);
	var5 = (var5 < 0 ? 0 : var5);
	var5 = (var5 > 419430400 ? 419430400 : var5);
	Hum = (uint32_t)(var5 / 4096);
	if (Hum > Hum_max){Hum = Hum_max;}

	return Hum;
}

//**********************************************************************************************************************************
//Отправка адреса устройства 
void BME280WriteAddress(uint8_t RxTxCondition)
{ 
  if (RxTxCondition == 0) {TxBufferI2C1[AddressBME280] = ADDR_BME280_WRITE_MODE;}    
  else                    {TxBufferI2C1[AddressBME280] = ADDR_BME280_READ_MODE;}
}



