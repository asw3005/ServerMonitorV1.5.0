/* Created: 27.05.2018
 * BME280.h
 * 
 * 
 * 
 */	
 
#ifndef BME280_H_
#define BME280_H_

#include "stm32f10x.h"

//***************************************************************************************************************************************
//Константы

#define ADDR_BME280                     0xEC                                //7 bit MSB 0x76 (address) + 1 bit LSB 0x00 (read/write)
#define WRITE_MODE									    0x00																	//режим записи в ведомое устройство				
#define READ_MODE										    0x01															  //режим чтения из ведомого устройства

#define ADDR_BME280_WRITE_MODE	        (ADDR_BME280 | WRITE_MODE)		        //Отправить адрес ведомого устройства, режим запись 
#define ADDR_BME280_READ_MODE				    (ADDR_BME280 | READ_MODE)			      //Отправить адрес ведомого устройства, режим чтение

#define CALIB00_START_ADDR              0x88
#define CALIB25_FINISH_ADDR             0xA1
#define ID_ADDR                         0xD0
#define RESET_ADDR                      0xE0
#define CALIB26_START_ADDR              0xE1
#define CALIB41_FINISH_ADDR             0xF0
#define CTRL_HUM_ADDR                   0xF2
#define STATUS_ADDR                     0xF3
#define CTRL_MEAS_ADDR                  0xF4
#define CONFIG_ADDR                     0xF5
#define PRESS_MSB_ADDR                  0xF7
#define PRESS_LSB_ADDR                  0xF8
#define PRESS_XLSB_ADDR                 0xF9
#define TEMP_MSB_ADDR                   0xFA
#define TEMP_LSB_ADDR                   0xFB
#define TEMP_XLSB_ADDR                  0xFC
#define HUM_MSB_ADDR                    0xFD
#define HUM_LSB_ADDR                    0xFE

//***************************************************************************************************************************************
//Расположение данных в буфере передачи
#define AddressBME280                   0x00
#define AddressRegisterCtrlHum          0x01
#define DataCtrlHum                     0x02
#define AddressRegisterCtrlMeas         0x03
#define DataCtrlMeas                    0x04
#define AddressRegisterConfig           0x05
#define DataConfig                      0x06

//***************************************************************************************************************************************
//Данные адреса расположения данных в буфере приёма
#define dig_T1_LSB                      0x00
#define dig_T1_MSB                      0x01
#define dig_T2_LSB                      0x02
#define dig_T2_MSB                      0x03
#define dig_T3_LSB                      0x04
#define dig_T3_MSB                      0x05
#define dig_P1_LSB                      0x06
#define dig_P1_MSB                      0x07
#define dig_P2_LSB                      0x08
#define dig_P2_MSB                      0x09
#define dig_P3_LSB                      0x0A
#define dig_P3_MSB                      0x0B
#define dig_P4_LSB                      0x0C
#define dig_P4_MSB                      0x0D
#define dig_P5_LSB                      0x0E
#define dig_P5_MSB                      0x0F
#define dig_P6_LSB                      0x10
#define dig_P6_MSB                      0x11
#define dig_P7_LSB                      0x12
#define dig_P7_MSB                      0x13
#define dig_P8_LSB                      0x14
#define dig_P8_MSB                      0x15
#define dig_P9_LSB                      0x16
#define dig_P9_MSB                      0x17 
//0x18
#define dig_H1_LSB                      0x19    
//0x1A - - - 0x47 (46 байт)
#define id                              0x48
//0x49 - - - 0x59 (15 байт)
#define reset                           0x5A
#define dig_H2_LSB                      0x5B
#define dig_H2_MSB                      0x5C
#define dig_H3_LSB                      0x5D
#define dig_H4_MSB                      0x5E
#define dig_H4H5_LSB                    0x5F
#define dig_H5_MSB                      0x60
#define dig_H6_LSB                      0x61
#define calib33                         0x62
#define calib34                         0x63
#define calib35                         0x64
#define calib36                         0x65
#define calib37                         0x66
#define calib38                         0x67
#define calib39                         0x68
#define calib40                         0x69
#define calib41                         0x6A
//0x6B
#define ctrl_hum                        0x6C
#define status                          0x6D
#define ctrl_meas                       0x6E
#define config                          0x6F
//0x70
#define press_msb                       0x71
#define press_lsb                       0x72
#define press_xlsb                      0x73
#define temp_msb                        0x74
#define temp_lsb                        0x75
#define temp_xlsb                       0x76
#define hum_msb                         0x77
#define hum_lsb                         0x78

//***************************************************************************************************************************************
//Состояние СБРОС (остальные коды не имеют воздействия)
#define RESET_STATE                     0xB6

//***************************************************************************************************************************************
//Настройка режима сбора данных о влажности CTRL_HUM (в состоянии SKIPPED влажность имеет значение 0x8000)
#define OSRS_H_SKIPPED                  0x00
#define OSRS_H_OVERSAMPLING_1           0x01
#define OSRS_H_OVERSAMPLING_2           0x02
#define OSRS_H_OVERSAMPLING_4           0x03
#define OSRS_H_OVERSAMPLING_8           0x04
#define OSRS_H_OVERSAMPLING_16          0x05

//***************************************************************************************************************************************
//Настройка режима сбора данных о давлении и температуре, режима работы датчика CTRL_MEAS (в состоянии SKIPPED давление и температура 
//имеют значения 0x8000)
#define OSRS_P_SKIPPED                  0x00
#define OSRS_P_OVERSAMPLING_1           0x01
#define OSRS_P_OVERSAMPLING_2           0x02
#define OSRS_P_OVERSAMPLING_4           0x03
#define OSRS_P_OVERSAMPLING_8           0x04
#define OSRS_P_OVERSAMPLING_16          0x05

#define OSRS_T_SKIPPED                  0x00
#define OSRS_T_OVERSAMPLING_1           0x01
#define OSRS_T_OVERSAMPLING_2           0x02
#define OSRS_T_OVERSAMPLING_4           0x03
#define OSRS_T_OVERSAMPLING_8           0x04
#define OSRS_T_OVERSAMPLING_16          0x05

#define SLEEP_MODE                      0x00
#define FORCED_MODE                     0x01
//#define FORCED_MODE                     0x02
#define NORMAL_MODE                     0x03

//***************************************************************************************************************************************
//Настройка скорости, фильтрации и интерфейса обмена в регистре CONFIG
#define T_SB_500uS                      0x00
#define T_SB_62500uS                    0x01
#define T_SB_125mS                      0x02
#define T_SB_250mS                      0x03
#define T_SB_500mS                      0x04
#define T_SB_1000mS                     0x05
#define T_SB_10mS                       0x06
#define T_SB_20mS                       0x07

#define FILTER_OFF                      0x00
#define FILTER_COEFF2                   0x01
#define FILTER_COEFF4                   0x02
#define FILTER_COEFF8                   0x03
#define FILTER_COEFF16                  0x04

#define SPI3WIRE_EN                     0x01
#define SPI3WIRE_DIS                    0x00

//***************************************************************************************************************************************
//Прототипы функций
void BME280PreparationConfig(void);                       //Подготовка конфигурационных данных (работа внутри помещения)
void BME280WriteConfig(void);                             //Запись конфигурационных данных 
void getBME280CalibrationData0(void);                     //Получить калибровочные данные первый диапазон
void getBME280CalibrationData1(void);                     //Получить калибровочные данные первый диапазон 
void getBME280DataPressTempHum(void);                     //Получить данные о давлении, температуре и влажности 
uint32_t BME280PressureConv(void);                        //Преобразование давления 
int32_t BME280TemperatureConv(void);                      //Преобразование температуры
uint32_t BME280HumidityConv(void);                        //Преобразование влажности 
void BME280WriteAddress(uint8_t RxTxCondition);           //Отправка адреса устройства


#endif /* BME280_H_ */


