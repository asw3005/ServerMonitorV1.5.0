/* Created: 20.06.2018
 * main.c
 *
 *
 *
 */

#include "stm32f10x.h"
#include "main.h"
#include "delay.h"
#include "i2c1.h"
#include "I2C2.h"
#include "usart1.h"
#include "BME280.h"
#include "BinToBcd.h"
#include "DustSensor.h"
#include "TIM3.h"
#include "ADC1.h"
#include "TIM2.h"
#include "DS3231.h"
//#include "core_cm3.h"
//#include "math.h"

extern uint8_t QuantityByteI2C1Tx;
extern uint8_t QuantityByteI2C1Rx;
extern uint8_t CounterByteI2C1Tx;
extern uint8_t CounterByteI2C1Rx;
extern uint8_t FlagCalibDataRead;
extern uint8_t FlagConfigEn;
extern uint8_t FlagWriteData;
extern uint8_t FlagReadData;
extern uint8_t FlagTxEnable;
extern uint8_t FlagRxEnable;
extern uint8_t FlagRestartEn;
extern uint8_t FlagSwitch;
extern uint8_t RxBufferAddr;
extern uint8_t TxBufferI2C1[10];
extern uint8_t RxBufferI2C1[121];
extern uint8_t *PointerTxBuffer;
extern uint8_t *PointerRxBuffer;
extern uint8_t FlagTim2Cmp;

extern uint8_t QuantityByteI2C2Tx;
extern uint8_t QuantityByteI2C2Rx;
extern uint8_t CounterByteI2C2Tx;
extern uint8_t CounterByteI2C2Rx;
extern uint8_t FlagConfigEnI2C2;
extern uint8_t FlagWriteDataI2C2;
extern uint8_t FlagReadDataI2C2;
extern uint8_t FlagTxEnableI2C2;
extern uint8_t FlagRxEnableI2C2;
extern uint8_t FlagRestartEnI2C2;
extern uint8_t FlagSwitchI2C2;
extern uint8_t RxBufferAddrI2C2;
extern uint8_t TxBufferI2C2[20];
extern uint8_t RxBufferI2C2[20];
extern uint8_t *PointerTxBufferI2C2;
extern uint8_t *PointerRxBufferI2C2;
extern uint8_t FlagTim2CmpI2C2;


extern uint16_t CounterUSART1TX;           //Счётчик кол-ва переданных байт, USART2
extern uint16_t ByteNumberUSART1TX;        //Кол-во передаваемых байт, USART2
extern uint8_t *USART1TxPointer_8;
extern uint8_t TxBufferUsart1[14];
extern uint8_t FlagUsart1TXComplete;       //Флаг "данные отправлены" / "передающий буфер занят"

extern uint32_t Dust, ADC_Dust;
extern uint8_t DustDataCounter;

int32_t Temperature;
uint32_t Humidity;
uint64_t Pressure;
uint32_t VIB;
uint8_t Timer5S;
uint8_t Timer10S;
uint8_t CounterTransportDataToPC;
uint8_t CounterLedInvertion = 0;

//**********************************************************************************************************************************
//Основная программа							
int main(void)
{ 
	

	
	
	
	
  InitPeriph();															//настройка портов ввода/вывода, перефирии МК		
  InitPin();                                //
  //NVIC_PriorityGroupConfig(0);
  __NVIC_SetPriorityGrouping(3);
  TimInitForSensor();                       //Настройка таймера для опроса датчиков
  I2C1_Init();                              //Настройка модуля I2C
  USART1Config();                           //Настройка модуля UART
  USART1Enable();
  USART1TransmitterEnable();
  InitVariable();
  BME280PreparationConfig();                //Подготовка конфигурационных данных (работа внутри помещения) 
  TimInitForDustSensor();                   //Настройка таймера для формирования сигнала опроса датчика пыли
  ADC1InitForDustSensor();                  //Настройка АЦП
  TimInitForVibSensor();
  FlagTim2Cmp = 0;
  FlagConfigEn = 1;
  FlagSwitch = 1;

		
while(1)
{		
  if (FlagConfigEn == 1)
    {
      switch (FlagSwitch)
            {
              case 1:BME280WriteConfig();                                             //Запись настроек
                     if (FlagCalibDataRead)
                       {
                          FlagConfigEn = 0;
                          FlagSwitch = 0;
                          FlagTim2Cmp = 0;
                          //FlagCalibDataRead = 0;
                       }
                     else {FlagSwitch = 2;}                  
                     break;
              case 2:if (FlagWriteData == 0 && FlagReadData == 0 && FlagTim2Cmp == 1) //Считывание калибровочных данных диапазон 0
                        {
                          getBME280CalibrationData0();                        
                          FlagSwitch = 3;
                          FlagTim2Cmp = 0;                 
                        }
                     break;
              case 3:if (FlagWriteData == 0 && FlagReadData == 0 && FlagTim2Cmp == 1)//Считывание калибровочных данных диапазон 1
                        {
                          getBME280CalibrationData1();                        
                          FlagSwitch = 4;                     
                          FlagTim2Cmp = 0;                        
                        } 
                     break;          
              case 4:FlagConfigEn = 0;
                     FlagSwitch = 0;
                     FlagTim2Cmp = 0;
                     FlagCalibDataRead = 1;
                     break;
              default:__NOP();                                      
            }      
    }
  
    
  if (FlagConfigEn == 0)
    {
      if (CounterTransportDataToPC == 5)                     //Параметры считываются каждые 500мс
        {
          Timer2->CR1 |= TIM_CR1_CEN;	
          
          Timer5S = 0;
          Temperature = BME280TemperatureConv();      //Преобразование сырых данных температуры
          Humidity = BME280HumidityConv();            //Преобразование сырых данных влажности
          Humidity = (Humidity*1000)/1024;            //Корректировка скомпенсированной влажности
          Pressure = BME280PressureConv();            //Преобразование сырых данных давления
          Pressure = (Pressure*1000000)/133322;       //Перевод давления из паскалей в мм.рт.ст.  
          getDust();                                  //Измерить содержание пыли в воздухе
          getBME280DataPressTempHum();                //Прочесть сырые данные датчика         

//					if ((getI2C1BusyDetection()|getI2C1MSLDetection()) == 0x03)
//						{
//							__NOP();
//							__NOP();
//							__NOP();

//						}
					
        }

        if (Timer5S == 1)                                     //Передача параметров каждые 600мс
        {
          Timer2->CR1 &= ~TIM_CR1_CEN;
          Timer2->EGR |= TIM_EGR_UG;
          Timer5S = 0;
          //CounterTransportDataToPC = 0;
          SendData();                                 //Отправить данные через модуль UART
          VIB = 0;
        }
      
    }

}
  
}

//**********************************************************************************************************************************
//Отправка данных по последовательному порту
void SendData(void)
{
  if (!FlagUsart1TXComplete)                                  //Флаг "данные отправлены" / "передающий буфер занят"
    {
      ByteNumberUSART1TX = 14;                               //Кол-во передаваемых байт
      TxBufferUsart1[ID] = 0x01;                              //Идентификатор модуля
      TmpConvToTx(Temperature);                              //Подготовка температуры для передачи
      PressConvToTx((uint32_t)Pressure);                     //Подготовка давления для передачи
      HumConvToTx(Humidity);                                 //Подготовка влажности для передачи  
      
      TxBufferUsart1[DUSTmsb] = Dust>>8;                      //Подготовка величины содержания пыли для передачи
      TxBufferUsart1[DUSTlsb] = Dust & 0x00FF;
      
      TxBufferUsart1[VIBmsb] = VIB>>8;                      //Подготовка величины вибрации для передачи
      TxBufferUsart1[VIBlsb] = VIB & 0x00FF;
      
      TxBufferUsart1[CRC8] = VerifyCRC8();
      
      CounterUSART1TX = 0;                                   //Обнулить счётчик переданных байт, USART2 
      FlagUsart1TXComplete = 1;                              //Установить флаг "данные отправлены" / "передающий буфер занят"
      USART1TXEInterruptEnable();                            //Включить прерывание по событию "передающий регистр данных пуст", USART2
    } 
}

//**********************************************************************************************************************************
//Подсчёт контрольной суммы CRC8
uint8_t VerifyCRC8(void)
{
	uint8_t *pByte = (uint8_t *) &(TxBufferUsart1[ID]); 
  uint8_t  iterator, _crc = 0;

	for (iterator = 0; iterator < sizeof(TxBufferUsart1) - 1; iterator++, pByte++)
    {    
      _crc = CRC8Table[_crc^*pByte];
    }
 
	return _crc;
}

//**********************************************************************************************************************************
//Инициализация перифирии	
void InitPeriph (void)
{                
  EnableClockPeriph();			                                //Включение тактирования перифирии					
  EnDisJTAGSW(); 							                              //Конфигурирование JTAG и SWD					
  EnableClockOut();   					                            //Вывод рабочей частоты на вывод 8 порта А	
                            
  //__ASM volatile ("cpsid CounterTransportDataToPC");                         
  __enable_irq();									                          //глобальное разрешение прерываний
}
			
//**********************************************************************************************************************************
//Включение тактирования перифирии	
void EnableClockPeriph(void)			
{
  RCC->APB2ENR	|= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_IOPCEN | RCC_APB2ENR_AFIOEN;   //включить тактирование порта А, альтернативных функций
  //RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;		                                          	                    											//включить тактирование таймера 2	 
  //RCC->APB2ENR |= RCC_APB2ENR_SPI1EN | RCC_APB2ENR_USART2EN;
}
			
//**********************************************************************************************************************************
//Конфигурирование JTAG и SWD
void EnDisJTAGSW(void)			
{
  AFIO->MAPR |= AFIO_MAPR_SWJ_CFG_1;  											//отключить JTAG, оставить включённым SW-DP 
}		
	
//**********************************************************************************************************************************
//Вывод рабочей частоты на вывод 8 порта А	
void EnableClockOut(void)			
{
  GPIOA->CRH	&= ~GPIO_CRH_CNF8;											      //сброс CNF									
  GPIOA->CRH  |= GPIO_CRH_CNF8_1 | GPIO_CRH_MODE8;		        //режим PP-AF  
  RCC->CFGR  |= RCC_CFGR_MCO_SYSCLK;                        // вывод MCO включён, источник SysClk
}
           
//**********************************************************************************************************************************
//Конфигурация внешних выводов
void InitPin(void)			
{ 
	//AFIO->MAPR |= AFIO_MAPR_TIM3_REMAP_1;  											//переключение канала TIM2_CH4 на PB11 
  //GPIOA->CRL	&= ~(GPIO_CRL_CNF2 | GPIO_CRL_CNF3 | GPIO_CRL_CNF4);			      //сброс CNF в 00				

	//GPIOA->CRL	&= ~GPIO_CRL_CNF5;			                                						 //сброс CNF в 00								
  //GPIOA->CRL  |= GPIO_CRL_MODE5;	                                      						 //установка режима РР-GP  
  
  GPIOC->CRL	&= ~GPIO_CRL_CNF4;			                                						 //сброс CNF в 00								
  GPIOC->CRL  |= GPIO_CRL_MODE4;	                                      						 //установка режима РР-GP  
}     

//**********************************************************************************************************************************
//Инициализация используемых переменных, структур, указателей и массивов
void InitVariable(void)			
{ 
  QuantityByteI2C1Tx = 0;
  QuantityByteI2C1Rx = 0;
  CounterByteI2C1Tx = 0;
  CounterByteI2C1Rx = 0;
  FlagCalibDataRead = 0;
  Timer5S = 0;
  Timer10S = 0;
  CounterTransportDataToPC = 0; 
  FlagConfigEn = 0;
  FlagWriteData = 0;
  FlagReadData = 0;
  FlagTxEnable = 0;
  FlagRxEnable = 0;
  FlagRestartEn = 0;
  FlagSwitch = 0;
  RxBufferAddr = 0;
	PointerTxBuffer = 0;
  PointerRxBuffer = 0;
}

//**********************************************************************************************************************************
//Обработчик прерывания от I2C1 		
void I2C1_EV_IRQHandler(void) 
{
  volatile  uint16_t StatusReadForClear;
  //uint16_t Reverse = 0; 
  //uint16_t RegisterStatus;
   
  if (getI2C1StartDetection())                                                              //Проверка генерации состояния СТАРТ
    {     
      I2C1->DR = TxBufferI2C1[AddressBME280];                                                   //Запись адреса ведомого
      //I2C1->CR1 &= ~I2C_SR1_AF;
      if (FlagRestartEn == 1){I2C1_EnAck();}                                                //При считывании включить формирование ответа ведомому   
      __NOP();
      return;
    }
    
  if (getI2C1AddrTxRx() == 1)                                                               //Проверка совпадения адреса ведомого
    { 
      StatusReadForClear = I2C1->SR2;
      return;
    }
    
  if ((getI2C1AddrTxRx() == 0)&&(getI2C1TXDataRegisterEmpty())&&(FlagTxEnable == 1))        //Передача давнных ведомому
    {StatusReadForClear = I2C1->DR;
      if (CounterByteI2C1Tx < QuantityByteI2C1Tx)
        {    
          I2C1->DR = TxBufferI2C1[CounterByteI2C1Tx+1];          
          CounterByteI2C1Tx++;
          return;
        }
      else 
        { 
          FlagTxEnable = 0;                                                                 //Передача последнего байта
          FlagWriteData  = 0;
          CounterByteI2C1Tx = 0;                              
          if (FlagRestartEn == 0){I2C1_Stop();}                                             //Генерация состояния СТОП при отправке данных ведомому
          else {BME280WriteAddress(READ_MODE); I2C1_Start();}                               //Иначе повторный старт 
          return;
        } 
      
    }
  
  if (getI2C1RXDataRegisterNotEmpty()&&FlagRxEnable == 1)                                   //Чтение данных ведомого
    { 
      if (CounterByteI2C1Rx < QuantityByteI2C1Rx)
        {//if (QuantityByteI2C1Rx>2)
            //{
          if (CounterByteI2C1Rx == QuantityByteI2C1Rx-2)                                    //Чтение с N-2 байта происходит с отключённым ответом от мастера
              {I2C1_DisAck();}
            //}   
              
          RxBufferI2C1[CounterByteI2C1Rx + RxBufferAddr] = I2C1->DR;
          CounterByteI2C1Rx++;   
          __NOP(); 
              
          if (CounterByteI2C1Rx == QuantityByteI2C1Rx)                                      //Чтение последнего байта
            {  
              FlagRestartEn = 0;             
              FlagRxEnable = 0;
              FlagReadData = 0;
              RxBufferAddr = 0;
              CounterByteI2C1Rx = 0;
              I2C1_Stop(); 
            }           
          return;
        }        
      
    }   
 
  if (getI2C1AFDetection())                                                               //Проверка совпадения адреса ведомого
    { 

      DelayTimer->CR1 &= ~TIM_CR1_CEN;			                      //выключение таймера	
      TIM4->CNT = 0;	
      TIM4->SR &= ~TIM_SR_UIF;									                  //сброс флага прерывания | TIM_SR_CC1IF 
      CounterTransportDataToPC = 0;
      Timer5S = 0;

      I2C1StatusRegister1 &= ~I2C_SR1_AF;
      
      FlagTim2Cmp = 0;
      FlagConfigEn = 1;
      FlagSwitch = 1;

      DelayTimer->CR1 |= TIM_CR1_CEN;
      return;
    }
    
   if (getI2C1BERRDetection())
    {
      I2C1StatusRegister1 &= ~I2C_SR1_BERR;
      
      DelayTimer->CR1 &= ~TIM_CR1_CEN;			                      //выключение таймера	
      TIM4->CNT = 0;	
      TIM4->SR &= ~TIM_SR_UIF;									                  //сброс флага прерывания | TIM_SR_CC1IF 
      CounterTransportDataToPC = 0;
      Timer5S = 0;
      
      FlagTim2Cmp = 0;
      FlagConfigEn = 1;
      FlagSwitch = 1;

      DelayTimer->CR1 |= TIM_CR1_CEN;
    
      return;
    } 

      
//      if (getI2C1STOPDetection())
//        {
//          StatusReadForClear = I2C1->SR1;
//          StatusReadForClear = I2C1->CR1;
//          I2C1StatusRegister1 = StatusReadForClear;
//          return;
//        }
  StatusReadForClear = I2C1->DR;  
}

//**********************************************************************************************************************************
////Обработчик прерывания от I2C2 		
//void I2C2_EV_IRQHandler(void) 
//{
//  volatile uint16_t StatusReadForClear;
//   
//  if (getI2C2StartDetection())                                                              //Проверка генерации состояния СТАРТ
//    {     
//      I2C2->DR = TxBufferI2C2[AddressDS3231];                                                   //Запись адреса ведомого
//      if (FlagRestartEnI2C2 == 1){I2C2_EnAck();}                                                //При считывании включить формирование ответа ведомому   
//      __NOP();
//      return;
//    }
//    
//  if (getI2C2AddrTxRx() == 1)                                                               //Проверка совпадения адреса ведомого
//    { 
//      StatusReadForClear = I2C2->SR2;
//      return;
//    }
//    
//  if ((getI2C2AddrTxRx() == 0)&&(getI2C2TXDataRegisterEmpty())&&(FlagTxEnableI2C2 == 1))        //Передача давнных ведомому
//    {StatusReadForClear = I2C2->DR;
//      if (CounterByteI2C2Tx < QuantityByteI2C2Tx)
//        {    
//          I2C2->DR = TxBufferI2C2[CounterByteI2C2Tx+1];          
//          CounterByteI2C2Tx++;
//          return;
//        }
//      else 
//        { 
//          FlagTxEnableI2C2 = 0;                                                                 //Передача последнего байта
//          FlagWriteDataI2C2  = 0;
//          CounterByteI2C2Tx = 0;                              
//          if (FlagRestartEnI2C2 == 0){I2C2_Stop();}                                             //Генерация состояния СТОП при отправке данных ведомому
//          else {DS3231WriteAddress(READ_MODE); I2C2_Start();}                               //Иначе повторный старт 
//          return;
//        } 
//      
//    }
//  
//  if (getI2C2RXDataRegisterNotEmpty()&&FlagRxEnableI2C2 == 1)                                   //Чтение данных ведомого
//    { 
//      if (CounterByteI2C2Rx < QuantityByteI2C2Rx)
//        {//if (QuantityByteI2C1Rx>2)
//            //{
//          if (CounterByteI2C2Rx == QuantityByteI2C2Rx-2)                                    //Чтение с N-2 байта происходит с отключённым ответом от мастера
//              {I2C2_DisAck();}
//            //}   
//              
//          RxBufferI2C2[CounterByteI2C2Rx + RxBufferAddrI2C2] = I2C2->DR;
//          CounterByteI2C2Rx++;   
//          __NOP(); 
//              
//          if (CounterByteI2C2Rx == QuantityByteI2C2Rx)                                      //Чтение последнего байта
//            {  
//              FlagRestartEnI2C2 = 0;             
//              FlagRxEnableI2C2 = 0;
//              FlagReadDataI2C2 = 0;
//              RxBufferAddrI2C2 = 0;
//              CounterByteI2C2Rx = 0;
//              I2C2_Stop(); 
//            }           
//          return;
//        }        
//      
//    }   
//    
//  //GPIOA->BSRR = GPIO_BSRR_BS5;
//  //GPIOA->BSRR = GPIO_BSRR_BR5;
//  StatusReadForClear = I2C2->DR;                                                            //Сброс флага
//}

//**********************************************************************************************************************************
//Обработчик прерывания от USART2 (события)		
void USART1_IRQHandler(void) 
{
  //uint8_t ReadWriteBuffer;

  if (getUSART1TXDataRegisterEmpty()&&getUSART1TXIOn())                         //Передающий регистр пуст
    {  
      USART1TxPointer_8 = (uint8_t *)& TxBufferUsart1[ID];                       //Определение адреса буфера для передачи данных
      USART1TxPointer_8 = USART1TxPointer_8 + CounterUSART1TX;                  //Сложить адрес буфера с необходимым смещением
      USART1DataRegister = (*USART1TxPointer_8);                                //Записать передаваемый байт в регистр данных, сброс флага события "передающий буфер пуст" 
      CounterUSART1TX++;  
      if (CounterUSART1TX == ByteNumberUSART1TX)
        {
          USART1TXEInterruptDisable();                                          //Выключить прерывание по событию "передающий регистр данных пуст", USART2
          CounterUSART1TX = 0;
          FlagUsart1TXComplete = 0;                                             //Сбросить флаг "данные отправлены" / "передающий буфер занят"  
					//DelayTimer->CR1 |= TIM_CR1_CEN;	            						  					//Включить таймер
        } 
    }
}	

//**********************************************************************************************************************************
//Обработчик прерывания от TIM4 (события)			
void TIM4_IRQHandler(void) 
{
  uint16_t Reverse = 0; 
  
  TIM4->SR &= ~TIM_SR_UIF;									                  //сброс флага прерывания | TIM_SR_CC1IF 
  FlagTim2Cmp = 1;
  CounterTransportDataToPC++;

  if (CounterTransportDataToPC == 6)                                                  //Формирование паузы для работы с датчиком
    {
      Timer5S = 1;
      CounterTransportDataToPC = 0;
    }
   
  if (CounterLedInvertion == 10)                             //Мигание светодиодом раз в секунду (прерывание вызывается раз в 100мс)
      {
        CounterLedInvertion = 0;
        Reverse = GPIOC->ODR;                                     //Переключение уровня для светодиода на выводе PA5
        Reverse &= 0x0010;
        if (Reverse == 16){GPIOC->BSRR = GPIO_BSRR_BR4;}
        else              {GPIOC->BSRR = GPIO_BSRR_BS4;}
      }
  else {CounterLedInvertion++;}    
}

//**********************************************************************************************************************************
//Обработчик прерывания от TIM3 (события)			
void TIM3_IRQHandler(void) 
{
  TIM3->SR &= ~TIM_SR_UIF;									                //сброс флага прерывания | TIM_SR_CC1IF 
  TIM3->SR &= ~TIM_SR_CC4IF;									                //сброс флага прерывания
  //Timer->CR1 |= TIM_CR1_CEN;			                          //включение таймера (в данном месте для перезапуска таймера в однократном режиме)
}

//**********************************************************************************************************************************
//Обработчик прерывания от TIM2 (события)			
void TIM2_IRQHandler(void) 
{
  TIM2->SR &= ~TIM_SR_UIF;									                //сброс флага прерывания | TIM_SR_CC1IF 
  TIM2->SR &= ~TIM_SR_CC2IF;									                //сброс флага прерывания

  VIB = TIM2->CCR2;
  TIM2-> CCR2 = 0;
  VIB = VIB*200;  
  VIB = 1000000/VIB;
}

//**********************************************************************************************************************************
//Обработчик прерывания от TIM1 (события)			
//void TIM1_CC_IRQHandler(void) 
//{
//  TIM1->SR &= ~TIM_SR_UIF;									                //сброс флага прерывания | TIM_SR_CC1IF 
//  Timer->CR1 |= TIM_CR1_CEN;			                  //включение таймера (в данном месте для перезапуска таймера в однократном режиме)
//}

//**********************************************************************************************************************************
//Обработчик прерывания от TIM1 (события)			
//void TIM1_UP_IRQHandler(void) 
//{
//  TIM1->SR &= ~TIM_SR_UIF;									                //сброс флага прерывания | TIM_SR_CC1IF 
//  //TIM1->SR &= ~TIM_SR_CC2IF;									                //сброс флага прерывания | TIM_SR_CC1IF
//  //TIM1->SR &= ~TIM_SR_CC3IF;									                //сброс флага прерывания | TIM_SR_CC1IF
//  //Timer->CR1 |= TIM_CR1_CEN;			                  //включение таймера (в данном месте для перезапуска таймера в однократном режиме)
//}


//**********************************************************************************************************************************
//Обработчик прерывания от ADC1_2 (события)			
void ADC1_2_IRQHandler(void) 
{
  ADC1->SR &= ~ADC_SR_JEOC;
  ADC_Dust = ADC_Dust + ADC1->JDR1;
  DustDataCounter++;
}


