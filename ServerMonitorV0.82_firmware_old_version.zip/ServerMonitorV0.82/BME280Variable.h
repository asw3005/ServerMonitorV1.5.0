/* Created: 27.05.18
 * BME280.h
 *
 * 
 * 
 */ 


#ifndef BME280Variable_H_
#define BME280Variable_H_

#include "stm32f10x.h"
#include "BME280.h"

//**********************************************************************************************************************************
//Структуры данных 
struct                                          //Заполнение для данных настройки
{
  uint8_t   osrs_h                    :3;    
  uint8_t   RESERVED_0                :5;
  
  uint8_t   mode                      :2;   
  uint8_t   osrs_p                    :3;
  uint8_t   osrs_t                    :3;  
  
  uint8_t   spi3w_en      						:1;   
  uint8_t   RESERVED_1                :1;
  uint8_t   filter        						:3;   
  uint8_t   t_sb          						:3;   
  
} BME280ConfigBit;


#endif /* BME280Variable_H_ */
