/* Created: 23.06.2018
 * TIM4.h
 *
 *
 *
 */	
 
 
#include "stm32f10x.h"
#include "TIM4.h" 

//*************************************************************************************************
//Настройка таймера для циклического опроса датчиков (частота 1с)
void TimInitForVibSensor(void)
{        		 
  //NVIC_SetPriority (TIM4_IRQn, 5);		                      //назначить приоритет прерывания от таймера 2 
  NVIC_EnableIRQ (TIM4_IRQn);				                          //глобальное разрешение прерываения таймера 2
  
  GPIOA->CRL	&= ~GPIO_CRL_CNF6;                              //Сброс CNF в 00
  GPIOA->CRL	|= GPIO_CRL_CNF6_1;                             //Установка режима AF-PP
  GPIOA->CRL  |= GPIO_CRL_MODE6_0;                            //Установка режима outmax 10MHz 
  
  RCC->APB1ENR |=RCC_APB1ENR_TIM4EN;		                      //включить тактирование таймера 2
  Timer4->PSC = 359; 				                                  //предделитель таймера (при 36МГц, делителе 360, после деления 100КГц - 10мкс	
  Timer4->ARR = 1000;					  		                          //значение предзагрузки/перезагрузки	(10ms)	1000!
  //Timer->CCR1 = 32;
  //Timer->CCR4 = 28;
  Timer4->CCMR2 |= TIM_CCMR2_CC4S_0;                           //Режим входа, TI2
  Timer4->CCER |= TIM_CCER_CC4E;                               //Включить 4й канал захвата

  
  
  
//  Timer->CCMR2 |= TIM_CCMR2_OC4M | TIM_CCMR2_OC4PE;           //Режим PWM2, включить выход сигнала
//  Timer->CCER |= TIM_CCER_CC4E;
  
  Timer4->CR1 |= TIM_CR1_URS | TIM_CR1_ARPE;			              //обновление с помощью бита UG не устанавливает флаг прерывания
  Timer4->EGR |= TIM_EGR_UG;				                            //генерация события обновления  
  Timer4->DIER |= TIM_DIER_UIE;			                          //включить вызов прерывания от события от таймера
  
  Timer4->CR1 |= TIM_CR1_CEN;			                            //включение таймера	
  //TIM2->SR &= ~TIM_SR_UIF;                                  //
                                                              //TIM3_CCR4 - ивент для АЦП на 280мкс
}


