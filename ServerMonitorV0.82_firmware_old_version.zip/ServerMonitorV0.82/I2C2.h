/* Created: 27.05.2018
 * I2C2.h
 * 
 * 
 * 
 */	
 
#ifndef I2C2_H_
#define I2C2_H_

#include "stm32f10x.h"

//***************************************************************************************************************************************
//Константы

#define FREQ_PERIPH_I2C2 								        36000000															                //Входная частота перефирии (AHB1)
#define FREQ_I2C2    								            100000											  					              //Частота передачи-приёма данных на шине I2C
#define FREQ_RISE_I2C2   								        1000000  															                //Максимальное время нарастания фронта на шине
#define THIGH_I2C2												      1                             					              //Длитильность высокого уровня сигнала 
#define TLOW_I2C2        								        1                           					                //Длительность низкого уровня сигнала 
          
#define CCR_VALUE_I2C2   								        (FREQ_PERIPH_I2C2/((THIGH_I2C2+TLOW_I2C2)*FREQ_I2C2))	//Значение для регистра контроля частоты
#define TRISE_VALUE_I2C2 								        ((FREQ_PERIPH_I2C2/FREQ_RISE_I2C2)+1) 					      //Значение для регистра времени нарастания
          
#define ADDR_STM32F103_I2C2                     0x00
#define WRITE_MODE_I2C2									        0x00																	                //режим записи в ведомое устройство				
#define READ_MODE_I2C2										      0x01																		              //режим чтения из ведомого устройства

#define ADDR_STM32F103_WRITE_MODE_I2C2	        (ADDR_STM32F103_I2C2 | WRITE_MODE_I2C2)		            //Отправить адрес ведомого устройства, режим запись 
#define ADDR_STM32F103_READ_MODE_I2C2				    (ADDR_STM32F103_I2C2 | READ_MODE_I2C2)			          //Отправить адрес ведомого устройства, режим чтение

//***************************************************************************************************************************************
//

#define I2C2StatusRegister1              (I2C2->SR1)
#define I2C2StatusRegister2              (I2C2->SR2)

//***************************************************************************************************************************************
//Прототипы функций

void I2C2_Init(void);														  //Функция инициализации I2C
void I2C2_Enable(void);													  //Функция включения I2C			
void I2C2_Disable(void);														//Функция выключения I2C			
void I2C2_Start(void);														//Функция генерации ссостояния СТАРТ на линии I2C			
void I2C2_Stop(void);															//Функция генерации состояния СТОП на линии I2C			
void I2C2_EnAck(void);														//Функция включения генерации подтверждения получения байта		
void I2C2_DisAck(void);														//Функция выключения генерации подтверждения получения байта		
void I2C2_RESET(void);                            //Функция перезагрузки модуля I2C1
uint16_t getI2C2TXDataRegisterEmpty(void);        //Получить статус состояния регистра передачи I2C1
uint16_t getI2C2RXDataRegisterNotEmpty(void);       //Получить статус состояния регистра приёма I2C1
uint16_t getI2C2StopDetection(void);              //Получить статус состояния СТОП I2C1
uint16_t getI2C2ByteTransferFinished(void);         //Получить статус состояния передачи байта I2C1
uint16_t getI2C2AddrTxRx(void);                   //Получить статус состояния приёма или передачи адреса I2C1
uint16_t getI2C2StartDetection(void);               //Получить статус состояния СТАРТ I2C1
uint16_t getI2C2BusyDetection(void);              //Получить статус состояния шины I2C1
			
void I2C2_Send_SlaveAddr_Wr (uint8_t AddrWrite);								//Функция отправки адреса ведомого устройства, режим запись			
void I2C2_Send_SlaveAddr_Rd (uint8_t AddrRead);									//Функция отправки адреса ведомого устройства, режим чтение

			
void I2C2_Send_Byte (uint8_t Quantity_Bytes, uint8_t Data_Byte);		//Функция отправки данных			
uint8_t I2C2_Read_Byte (uint8_t Quantity_Bytes);											//Функция приёма данных



#endif /* I2C2_H_ */


