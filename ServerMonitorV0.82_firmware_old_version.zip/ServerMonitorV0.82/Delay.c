/* Created: 21.07.2016
 * Delay.c
 *
 *
 *
 */

#include "stm32f10x.h"
#include "Delay.h"

//uint8_t FlagTim2Cmp = 0;
uint8_t Flag;
uint16_t Delay = 0;

//*************************************************************************************************
//Настройка таймера для циклического опроса датчиков (частота 1с)
void TimInitForSensor(void)
{        		 
  NVIC_SetPriority (TIM4_IRQn, 2);		                      //назначить приоритет прерывания от таймера 2 
  NVIC_EnableIRQ (TIM4_IRQn);				                        //глобальное разрешение прерываения таймера 2
  
  
      
  RCC->APB1ENR |=RCC_APB1ENR_TIM4EN;		                    //включить тактирование таймера 2
  //DelayTimer->PSC = 720; 				                            //предделитель таймера (при 36МГц, делителе 720, после деления 50КГц - 20мкс	
  DelayTimer->PSC = 72; 				                            //
  DelayTimer->ARR = 50000;					  		                  //значение предзагрузки/перезагрузки	(1s)	50000!
  DelayTimer->CR1 |= TIM_CR1_URS;			                      //обновление с помощью бита UG не устанавливает флаг прерывания
  DelayTimer->EGR |= TIM_EGR_UG;				                    //генерация события обновления  
  DelayTimer->DIER |= TIM_DIER_UIE;			                    //включить вызов прерывания от события от таймера
      
  DelayTimer->CR1 |= TIM_CR1_CEN;			                      //включение таймера	
  //TIM2->SR &= ~TIM_SR_UIF;
}


